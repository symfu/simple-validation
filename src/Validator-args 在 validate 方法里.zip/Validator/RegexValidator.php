<?php
namespace Symfu\SimpleValidation\Validator;

class RegexValidator extends BaseValidator {
    const MESSAGE = 'simple_validation.errors.regex';

    protected $pattern   = '';
    protected $jsPattern = '';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        if (is_string($value) && strlen($value) < 1) {
            return [true, ''];
        }

        $regex = $arg;
        if (strlen($regex) < 1) {
            throw new \InvalidArgumentException("Invalid regex: {$regex}");
        }

        if (strlen($value) > 0 && !preg_match($regex, $value)) {
            return [false, static::MESSAGE];
        }

        return [true, ''];
    }

    public function toJQueryValidateRule() {
        $jsPattern = trim($this->jsPattern);

        if (strlen($jsPattern) < 1) {
            return null;
        }

        return ['regex' => $jsPattern];
    }
}
