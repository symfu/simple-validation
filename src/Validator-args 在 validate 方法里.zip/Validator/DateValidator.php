<?php
namespace Symfu\SimpleValidation\Validator;

class DateValidator extends RegexValidator
{
    const MESSAGE = 'simple_validation.errors.date';

    public function __construct()
    {
        $this->args = '/^\d\d\d\d[-\/\.]\d\d[-\/\.]\d\d$/';
    }

    public function validate($value, $arg, $fieldName, $formValues = [])
    {
        return parent::validate($value, $arg, $fieldName, $formValues);
    }

    public function toJQueryValidateRule()
    {
        return ['date' => true, 'regex' => $this->args];
    }
}
