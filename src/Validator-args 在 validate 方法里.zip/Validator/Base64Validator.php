<?php
namespace Symfu\SimpleValidation\Validator;

class Base64Validator extends BaseValidator {
    const MESSAGE = 'simple_validation.errors.base64';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        if (strlen($value) === 0) {
            return [true, ''];
        } else {
            $decoded = base64_decode($value);
            return $decoded ? [true, ''] : [false, static::MESSAGE];
        }
    }
}
