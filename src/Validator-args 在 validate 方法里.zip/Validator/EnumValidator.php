<?php
namespace Symfu\SimpleValidation\Validator;

use Symfu\SimpleValidation\ValidatorInterface;

class EnumValidator implements ValidatorInterface
{
    const MESSAGE = 'simple_validation.errors.enum';
    private $enums = [];
    private $useArrayKeys = false;
    public function __construct($enumValues = null, $useArrayKeys = false) {
        $this->useArrayKeys = $useArrayKeys;
        $this->setArgs($enumValues);
    }

    public function validate($value, $arg, $fieldName, $formValues = [])
    {
        if(strlen($value) > 0 && $this->enums && !in_array($value, (array)$this->enums))
        {
            return [false, static::MESSAGE];
        }

        return [true, ''];
    }

    private function setArgs($enumValues, $useArrayKeys = false) {
        if(is_string($enumValues)) {
            $validEnums = explode("|", trim($enumValues));
        } elseif(is_array($enumValues)) {
            $validEnums = $this->useArrayKeys ? array_keys($enumValues) : array_values($enumValues);
        } else {
            $validEnums = [];
        }

        array_walk($validEnums, function(&$v){ $v = trim($v);});
        $validEnums = array_filter($validEnums, function($v){ return $v !== '' && $v !== null;});

        $this->args = $validEnums;
    }

    public function toJQueryValidateRule()
    {
        return [];
    }
}
