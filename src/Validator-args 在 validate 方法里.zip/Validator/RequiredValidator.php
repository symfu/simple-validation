<?php
namespace Symfu\SimpleValidation\Validator;

class RequiredValidator extends BaseValidator {
    const MESSAGE = 'simple_validation.errors.required';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        return strlen($value) > 0 ? [true, ''] : [false, static::MESSAGE];
    }

    public function toJQueryValidateRule() {
        return ['required' => true];
    }

}
