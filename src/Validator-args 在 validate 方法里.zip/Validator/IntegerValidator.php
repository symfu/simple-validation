<?php
namespace Symfu\SimpleValidation\Validator;

class IntegerValidator extends RegexValidator
{
    const MESSAGE = 'simple_validation.errors.integer';

    public function __construct()
    {
        parent::__construct('/^[\-+]?[0-9]+$/');
        $this->jsPattern = $this->args;
    }

    public function validate($value, $arg, $fieldName, $formValues = [])
    {
        return parent::validate($value, $arg, $fieldName, $formValues);
    }

    public function toJQueryValidateRule()
    {
        return ['number' => true, 'regex' => $this->jsPattern];
    }
}
