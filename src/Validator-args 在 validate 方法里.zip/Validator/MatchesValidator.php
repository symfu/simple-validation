<?php
namespace Symfu\SimpleValidation\Validator;

class MatchesValidator extends BaseValidator
{
    const MESSAGE = 'simple_validation.errors.matches';

    public function validate($value, $arg, $fieldName, $formValues = [])
    {
        $matchField = trim($this->args);
        if(!$matchField || !isset($formValues[$matchField]) || ($value !== $formValues[$matchField]))
        {
            return [false, static::MESSAGE];
        }

        return [true, ''];
    }

    public function toJQueryValidateRule()
    {
        $target = $this->args;
        return array('equalTo' => $target);
    }
}
