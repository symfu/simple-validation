<?php
namespace Symfu\SimpleValidation\Validator;

class AlphaDashValidator extends RegexValidator {
    const MESSAGE = 'simple_validation.errors.alpha_dash';

    public function __construct($args) {
        parent::__construct($args);
        $this->pattern = $this->jsPattern = '/^[a-z0-9_-]+$/i';
    }

    public function validate($value, $arg, $fieldName, $formValues = []) {
        return parent::validate($value, $this->pattern, $fieldName, $formValues);
    }
}
