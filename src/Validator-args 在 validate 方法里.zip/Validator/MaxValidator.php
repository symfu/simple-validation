<?php
namespace Symfu\SimpleValidation\Validator;

class MaxValidator extends BaseValidator
{
    const MESSAGE = 'simple_validation.errors.max';

    public function validate($value, $arg, $fieldName, $formValues = [])
    {
        $compareTarget = trim($this->args);
        if(strlen($value) > 0 && $value > $compareTarget)
        {
            return [false, static::MESSAGE];
        }

        return [true, ''];
    }

    public function toJQueryValidateRule()
    {
        $len = (int)$this->args;
        return array('max' => $len);
    }
}
