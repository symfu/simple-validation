<?php
namespace Symfu\SimpleValidation\Validator;

class MinValidator extends BaseValidator {
    const MESSAGE = 'simple_validation.errors.min';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        $compareTarget = trim($arg);
        if (strlen($value) > 0 && (!is_numeric($value) || !is_numeric($compareTarget) || $value < $compareTarget)) {
            return [false, static::MESSAGE];
        }

        return [true, ''];
    }

    public function toJQueryValidateRule() {
        $len = (int)$this->args;

        return ['min' => $len];
    }
}
