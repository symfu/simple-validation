<?php
namespace Symfu\SimpleValidation\Validator;

class NumericValidator extends BaseValidator {
    const MESSAGE = 'simple_validation.errors.numeric';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        $valid = (strlen($value) < 1 || is_numeric($value));

        return $valid ? [true, ''] : [false, static::MESSAGE];
    }

    public function toJQueryValidateRule() {
        return ['number' => true];
    }

}
