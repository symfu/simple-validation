<?php
namespace Symfu\SimpleValidation\Validator;

class AlphaValidator extends RegexValidator
{
    const MESSAGE = 'simple_validation.errors.alpha';

    public function __construct()
    {
        $this->args = $this->jsPattern = '/^[a-z]+$/i';
    }

    public function validate($value, $arg, $fieldName, $formValues = [])
    {
        return parent::validate($value, $arg, $fieldName, $formValues);
    }
}
