<?php
namespace Symfu\SimpleValidation\Validator;

class MobileNumberValidator extends RegexValidator {
    const MESSAGE = 'simple_validation.errors.mobile';
    const PATTERN = '/^1\d{10}$/';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        return parent::validate($value, self::PATTERN, $fieldName, $formValues);
    }

    public function toJQueryValidateRule() {
        return ['regex' => self::PATTERN];
    }
}
