<?php

namespace Symfu\SimpleValidation\Validator;

class ExactLengthValidator extends BaseValidator {
    const MESSAGE = 'simple_validation.errors.exact_length';

    public function validate($value, $arg, $fieldName, $formValues = []) {
        if (strlen($value) === 0) {
            return [true, ''];
        }

        $len = trim($this->args);
        if (strlen($len) < 1 || preg_match('/[^0-9]/', $len)) {
            trigger_error("Invalid length argument: {$len}", E_USER_WARNING);

            return [false, static::MESSAGE];
        }

        $len         = (int)$len;
        $valueLength = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);

        if ($valueLength !== $len) {
            return [false, static::MESSAGE];
        }

        return [true, ''];
    }

    public function toJQueryValidateRule() {
        $len = (int)$this->args;

        return ['range' => [$len, $len]];
    }
}
